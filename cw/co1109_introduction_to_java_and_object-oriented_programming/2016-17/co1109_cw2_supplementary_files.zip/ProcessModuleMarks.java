import java.util.*;
import java.io.*;

public class ProcessModuleMarks{

	public static ArrayList<Student> StudentsInList(String s)throws IOException{
		ArrayList<Student> students = new ArrayList<Student>();
		String name;
		int exam;
		int cwk;
		Scanner in =new Scanner(new FileReader(s));
		while(in.hasNextLine()){
			name =in.nextLine();
			cwk = Integer.parseInt(in.nextLine());
			exam = Integer.parseInt(in.nextLine());
			students.add(new Student(name,exam,cwk));
		}
		in.close();//finished with the Scanner object, tidy up.
		return students;
	 }


	public static ArrayList<Student> StudentsInList_2(String s) throws IOException{
		ArrayList<Student> students = new ArrayList<Student>();
		String name;
		int exam;
		int cwk;
		Scanner in = new Scanner(new FileReader(s));
		while(in.hasNextLine()){
		  name =in.nextLine();
		  cwk = Integer.parseInt(in.nextLine());
		  exam = Integer.parseInt(in.nextLine());
		  Student X = new Student(name,exam,cwk);
		  int insertIndex = positionOfNext(students, X.getTotal());
		  students.add(insertIndex, X);
		}
		in.close();//finished with the Scanner object, tidy up.
	return students;
    }

	public static int positionOfNext(ArrayList<Student> a, int x){
		//some statements to add here...
		return 0;//this statement added to make the method compile (it must return an int, since it is of type int)
	}


    	public static void main(String[] args)throws IOException{
			 ArrayList<Student> students = StudentsInList("marks.txt");
			//DisplayStudents(students);
			 System.out.println();
			 System.out.println("/**************************************************/");
			 System.out.println();
			 //findStudentName(students, "Eb");
			 System.out.println();
			 System.out.println("/**************************************************/");
			 System.out.println();
			// ArrayList<Student> students2 = StudentsInList_2("marks.txt");
			 //DisplayStudents(students2);
			 System.out.println();
			 System.out.println("/**************************************************/");
			 System.out.println();
			// findStudentGrade(students2, "A");
			 System.out.println();
			 System.out.println("/**************************************************/");
			 System.out.println();
			/* System.out.println(binarySearch(students2, 35));
			 System.out.println(binarySearch(students2, 68));
			 System.out.println(binarySearch(students2, 69));
			 System.out.println(binarySearch(students2, 85));*/

			 //StudentsToFile(students2,"sortedMarks.txt");//test this by looking in the sortedMarks.txt file
		 }
}
