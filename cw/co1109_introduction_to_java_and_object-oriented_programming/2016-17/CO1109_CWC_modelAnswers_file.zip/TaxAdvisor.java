import java.math.BigDecimal;
import java.util.Scanner;

public class TaxAdvisor {

	private static boolean personalAllowance;
	private static boolean blind = false;
	private static boolean manualWorker = false;
	private static boolean uniformWearer = false;
	private static boolean worksFromHome = false;
	private static boolean laundryAllowance;
	private static BigDecimal salary;
	private static BigDecimal taxAllowance;
	private static BigDecimal taxTwenty;
	private static BigDecimal taxForty;
	private static BigDecimal taxFortyFive;
	private static BigDecimal taxBill;
	/*Note that in the TaxAdvisor class BigDecimal has been used for calculations. Students were told that they could use BigDecimal in their answers, since it is used in real world calculatins with currency for its accuracy, but that there were no marks for using the class. Many used BigDecimal, others used float or double.*/
	private static Scanner input = new Scanner(System.in);



	public static String ask(String question) {
		System.out.print(question);
		String answer = input.nextLine();
		return answer;
	}

	public static boolean yesOrNo(String string) {
		if (string.startsWith("y")) {
			return true;
		}
		return false;
	}

	public static void explainTaxes() {
		getTaxInfo();
		taxAllowance = calculateAllowance();
		taxTwenty=calc20(taxAllowance);
		taxForty = calc40();
		taxFortyFive=calc45();
		//taxBill = calculateBill(taxAllowance);
		System.out.println("Your salary is "+ salary);
		System.out.println("Your tax allowance is "+ taxAllowance);
		System.out.println("Your tax bill is as follows:");
		System.out.println("You owe "+taxTwenty+" in the first tax band (20% tax) paid on taxable income up to 43,000");
		System.out.println("You owe "+taxForty+" in the second tax band (40% tax) paid on taxable income above 43,000 and up to 150,000");
		System.out.println("You owe "+taxFortyFive+" in the third tax band (45% tax) paid on taxable income over 150,000");
		System.out.println("Total tax owed on your salary is "+(taxTwenty.add(taxForty).add(taxFortyFive)));
	}

	public static void getTaxInfo(){
		String answer = ask("What is your annual salary? ");
		salary = new BigDecimal(answer);
		if (salary.compareTo (new BigDecimal(122000)) == 1) {
			personalAllowance = false;
		} else {
			personalAllowance = true;
		}
		if (personalAllowance){
			answer = ask("Are you registered blind? ");
			blind = yesOrNo(answer);

			answer = ask("Are you a manual worker? ");
			manualWorker = yesOrNo(answer);

			answer = ask("Do you wear a uniform for work? ");
			uniformWearer = yesOrNo(answer);

			answer = ask("Do you work from home full time? ");
			worksFromHome = yesOrNo(answer);
		}
	}

	public static BigDecimal calculateAllowance() {
		BigDecimal allowance = new BigDecimal(0);
		if (personalAllowance) {
			allowance = allowance.add(new BigDecimal(11000));
		}

		if (blind) {
			allowance = allowance.add(new BigDecimal(2290));
		}

		if (manualWorker || uniformWearer) {
			allowance = allowance.add(new BigDecimal(60));
		}

		if (worksFromHome) {
			allowance = allowance.add(new BigDecimal(200));
		}

		return allowance;
	}

	public static BigDecimal calc20(BigDecimal allowance) {
		BigDecimal tax = new BigDecimal(0);
		BigDecimal taxable = new BigDecimal(0);
		if (salary.compareTo(allowance) != 1)  //if the salary is less than or equal to the allowance, return zero
			return tax;

		if (salary.compareTo(new BigDecimal(43000))!=1) //if the salary is less than or equal to 43000
			taxable = salary.subtract(allowance);
		else taxable = new BigDecimal(43000).subtract(allowance);
		return tax = calcTax(taxable, 20);
	}

	public static BigDecimal calc40() {
		BigDecimal tax = new BigDecimal(0);
		BigDecimal taxable = new BigDecimal(0);
		if (salary.compareTo(new BigDecimal(43000)) != 1) {
			//if the salary is less than or equal to start of the 40% tax band, return zero
			return tax; //no tax owed in this band
		}
		if (salary.compareTo(new BigDecimal(150000))!=1) {//if the salary is less than or equal to 150000
			taxable = salary.subtract(new BigDecimal(43000));}
		else {
			taxable = new BigDecimal(150000).subtract(new BigDecimal(43000));}
		return tax = calcTax(taxable, 40);
	}

	public static BigDecimal calc45() {
		BigDecimal tax = new BigDecimal(0);
		BigDecimal taxable = new BigDecimal(0);
		if (salary.compareTo(new BigDecimal(150000)) != 1) {
			//if the salary is less than or equal to start of the 40% tax band, return zero
			return tax; //no tax owed in this band
		}
		taxable = salary.subtract(new BigDecimal(150000));
		return tax = calcTax(taxable, 45);
	}


	public static BigDecimal calcTax(BigDecimal amount, int percentage) {
		return amount.divide(new BigDecimal(100)).multiply(new BigDecimal(percentage));
	}

	public static void main(String[] args) {
		explainTaxes();
	}
}
