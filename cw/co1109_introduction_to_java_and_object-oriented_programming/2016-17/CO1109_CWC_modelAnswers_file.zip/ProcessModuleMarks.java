import java.util.*;
import java.io.*;

public class ProcessModuleMarks{

	public static ArrayList<Student> StudentsInList(String s){
		ArrayList<Student> students = new ArrayList<Student>();
		String name;
		int exam;
		int cwk;
		try{
		Scanner in =new Scanner(new FileReader(s));
			while(in.hasNextLine()){
				name =in.nextLine();
				cwk = Integer.parseInt(in.nextLine());
				exam = Integer.parseInt(in.nextLine());
				students.add(new Student(name,exam,cwk));
			}
			in.close();//finished with the Scanner object, tidy up.
		}
		catch(FileNotFoundException ex){
			System.out.println("file "+s+" not found");
		}
		return students;
	 }

	 /************************************************************************/

	public static void DisplayStudents(ArrayList<Student> students){
	   String t="";
	   for (int i=0;i<students.size();i++) t=t+students.get(i) +"\n";
	   System.out.println(t);
	}

	/************************************************************************/


	public static void findStudentName(ArrayList<Student> a, String s){
		String search = s.toLowerCase();
		for (int i=1;i<a.size();i++)
		if (((a.get(i))).getName().toLowerCase().startsWith(search)){
			System.out.println(a.get(i));
		}
	}

	/************************************************************************/


	public static ArrayList<Student> StudentsInList_2(String s){
		ArrayList<Student> students = new ArrayList<Student>();
		String name;
		int exam;
		int cwk;

		try{
			Scanner in = new Scanner(new FileReader(s));
			while(in.hasNextLine()){
			  name =in.nextLine();
			  cwk = Integer.parseInt(in.nextLine());
			  exam = Integer.parseInt(in.nextLine());
			  Student X = new Student(name,exam,cwk);
			  int insertIndex = positionOfNext(students, X.getTotal());//find the place to insert
			  students.add(insertIndex, X);//insert
			}
			in.close();//finished with the Scanner object, tidy up.
		}
		catch(FileNotFoundException ex){
			System.out.println("file "+s+" not found");
		}
		return students;
    }

	/************************************************************************/

	public static int positionOfNext(ArrayList<Student> a, int x){
		int position = 0;
		if (a.size()==0) return 0;
		for (int i=0;i<a.size();i++)
			if (((a.get(i))).getTotal() > x){
				return i;
				//stop when we find the first total greater than x
			}
		return a.size();//if we do not find a total greater than x, the new object belongs at the end of the ArrayList
	}

	/************************************************************************/

    public static void findStudentGrade(ArrayList<Student> a, String s){
		for (int i=1;i<a.size();i++)
		if (((a.get(i))).getGrade().equals(s)){
			System.out.println(a.get(i));
		}
	}

	/************************************************************************/


	public static boolean binarySearch(ArrayList<Student> a, int thing){
		int size = a.size();
		int first=0,last=size-1;
		int mid;
		while (first <=last){
			mid=first + (last-first)/2;
			if (thing ==a.get(mid).getTotal()) return true;
			else if (thing < a.get(mid).getTotal()) last = mid-1;
			else first=mid+1;
		}
		return false;
	}

	/************************************************************************/

    public static void StudentsToFile(ArrayList<Student> student, String s){
		try{
			PrintStream out = new PrintStream(new FileOutputStream(s));
			for(int i = 0; i < student.size(); i++)
			out.println(student.get(i));
			out.close();
		}
		catch(FileNotFoundException ex){
			System.out.println("file "+s+" not found");
		}
	}

	/************************************************************************/


    	public static void main(String[] args){
			 ArrayList<Student> students = StudentsInList("marks.txt");
			 DisplayStudents(students);
			 System.out.println();
			 System.out.println("/**************************************************/");
			 System.out.println();
			 findStudentName(students, "EB");
			 System.out.println();
			 System.out.println("/**************************************************/");
			 System.out.println();
			 ArrayList<Student> students2 = StudentsInList_2("marks.txt");
			 DisplayStudents(students2);
			 System.out.println();
			 System.out.println("/**************************************************/");
			 System.out.println();
			 findStudentGrade(students2, "A");
			 System.out.println();
			 System.out.println("/**************************************************/");
			 System.out.println();
			 System.out.println(binarySearch(students2, 35));
			 System.out.println(binarySearch(students2, 68));
			 System.out.println(binarySearch(students2, 69));
			 System.out.println(binarySearch(students2, 85));

			 StudentsToFile(students2,"sortedMarks.txt");//test this by looking in the sortedMarks.txt file
		 }
}
