import java.util.Calendar;
import java.util.Scanner;

public class InvoiceCreator {
	//Name and address of the company doing the invoicing
	private static final String COMPANY_NAME = "Quality Employment Agency";
	private static final String COMPANY_PAYABLE_NAME = "Quality Employees Inc.";
	private static final String COMPANY_ADDRESS1 = "10 Sixth Road";
	private static final String COMPANY_ADDRESS2 = "Lodgate";
	private static final String COMPANY_POSTCODE = "LO15 9EE";
	private static final String COMPANY_SLOGAN = "Quality Employment Agency: where quality comes first";

	private static Scanner in;

	public static void create() {
		in = new Scanner(System.in);

		String name = "";
		String address = "";

		//ask the user for the name and address of the company receiving the invoice
		//name = getFromUser("name of company to invoice"); 				// ******TASK ONE******
		//address = getAddress();										// ******TASK TWO******

		String breakdownOfCosts = "";
		int totalHours = 0;
		int totalOwing = 0;


		boolean keepGoing = true;
		//loop so that the user can enter as many employees as they need to

/*		while (keepGoing) {
			//get user to enter a job name, pay rate and hours worked
			String jobTitle = getFromUser("job title"); 						// ******TASK ONE******
			int hourlyRate = getIntFromUser("hourly rate for " + jobTitle); 	// ******TASK THREE******
			int hours = getIntFromUser("hours worked for " + jobTitle);			// ******TASK THREE******

			//update invoice
			breakdownOfCosts += addEmployeeToInvoice(jobTitle, hourlyRate, hours);
			totalHours += hours;
			totalOwing += (hourlyRate * hours);

			//add more employees to the invoice?
			String more = getFromUser("another worker? Yes/No"); 				// ******TASK ONE******
			if (more.trim().toLowerCase().startsWith("n")) {
				keepGoing = false;
			}
		} //all done with user input.
*/

		//print the formatted invoice
		printInvoice(name, address, totalHours, totalOwing, breakdownOfCosts);

		//clean up
		in.close();
	}

	private static String addEmployeeToInvoice(String jobTitle, int hourlyRate, int hours) {
		//format: name, £hourly rate, hours worked, £amount owed
		return String.format("%-25s\t£%d\t\t%d\t\t£%d%n", jobTitle, hourlyRate, hours, hourlyRate *hours);
	}



	private static void printInvoice(String name, String address, int totalHours, int totalBeforeVat, String breakdownOfCosts) {
		int vat = 0;
		int totalWithVat = 0;

		//vat = getVat(totalBeforeVat); 		 								//******TASK FOUR*******
		//totalWithVat = addVat(totalBeforeVat); 								//******TASK FIVE*******


		// \t = tab, %n = newline

		String s = String.format("\t\t\t%s%n%n%n", COMPANY_NAME);

		s += String.format("INVOICE%n%n%s%n%n", getTodaysDate());
		s += String.format("%s%n%s%n%s%n%s%n%n", COMPANY_NAME, COMPANY_ADDRESS1, COMPANY_ADDRESS2, COMPANY_POSTCODE);
		s += String.format("TO%n%s%n%s%n%n", name, address);
		s += String.format("JOB TITLE\t\t\tHOURLY RATE\tHOURS WORKED\tAMOUNT%n%s%n",breakdownOfCosts);
		s += String.format("Total Hours\t\t\t\t\t\t\t%d%n", totalHours);
		s += String.format("Total Before VAT\t\t\t\t\t\t£%d%n", totalBeforeVat);
		s += String.format("VAT @ 20%%\t\t\t\t\t\t\t£%d%n%n", vat);
		s += String.format("==========================================================================%n","");
		s += String.format("TOTAL PAYABLE\t\t\t\t\t\t\t£%d%n", totalWithVat);
		s += String.format("==========================================================================%n%n%n","");
		s += String.format("DETAILS%nSee attached time sheets.%n%n%nPAYMENT%nMake all cheques payable to %s%n", COMPANY_PAYABLE_NAME);
		//s += String.format("Total due in 30 days from date of invoice.%n%n%nThe total payment of £%d is due on or before %s.%n%n%n", totalWithVat, getDateIn30Days());											//	******TASK SIX*******

		s += String.format("Thank you for your custom.%n%n%n\t\t%s", COMPANY_SLOGAN);

		System.out.println(s);
	}


	private static String getTodaysDate() {
		Calendar today = Calendar.getInstance();

		//format returned is dd/mm/yy
		return String.format("%1$te/%1$tm/%1$ty", today);
	}


	public static void main(String[] args) {
		InvoiceCreator.create();
	}
}
