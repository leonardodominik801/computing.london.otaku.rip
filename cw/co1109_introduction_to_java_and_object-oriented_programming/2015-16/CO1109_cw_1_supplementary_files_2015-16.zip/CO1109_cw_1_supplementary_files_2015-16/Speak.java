
public class Speak{
	private static String[] words_1 = {"Mr Spock","Captain","Bones","Scotty","Uhura","Sulu","Checkov"};
	private static String[] words_2 = {"your","my","their","the"};
	private static String[] words_3 = {"best friend","warp drive","lunch","tribble","Klingon Ambassador","tricorder"};
	private static String[] words_4 = {"is life but not as we know it","is behind you","ate my hamster","has taken over the ship","cannae take much more of this","has run amok","is looking at me strangely","is decloaking"};
}

