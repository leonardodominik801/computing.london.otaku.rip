import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Receipts {

	public static List<String> readFromFile(String filename) {
		try {
			Scanner in = new Scanner(new FileReader(filename));
			List<String> list = new ArrayList<String>();
			while(in.hasNextLine()) {
				String line = in.nextLine();
				list.add(line);
			}
			in.close();
			return list;
		} catch (IOException e) {
			System.err.format("Error reading from file: %s%n", e);
			return null;
		}
	}

	public static void writeToFile(String filename, List<String> contents) {
		try {
			FileWriter writer =  new FileWriter(filename);
			for (int i = 0; i < contents.size(); i++) {
				writer.write(String.format("%s%n", contents.get(i)));
			}
			writer.close();
		} catch (IOException e) {
			System.err.format("Error writing receipt to disk: %s%n", e);
			return;
		}
	}
}
