import java.util.Calendar;
import java.util.Scanner;

public class InvoiceCreator {
	//Name and address of the company doing the invoicing
	private static final String COMPANY_NAME = "Quality Employment Agency";
	private static final String COMPANY_PAYABLE_NAME = "Quality Employees Inc.";
	private static final String COMPANY_ADDRESS1 = "10 Sixth Road";
	private static final String COMPANY_ADDRESS2 = "Lodgate";
	private static final String COMPANY_POSTCODE = "LO15 9EE";
	private static final String COMPANY_SLOGAN = "Quality Employment Agency: where quality comes first";

	private static Scanner in;

	public static void create() {
		in = new Scanner(System.in);

		//ask the user for the name and address of the company receiving the invoice
		String name = getFromUser("name of company to invoice");
		String address = getAddress();

		String breakdownOfCosts = "";
		int totalHours = 0;
		int totalOwing = 0;
		boolean keepGoing = true;
		//loop so that the user can enter as many employees as they need to
		while (keepGoing) {
			//get user to enter a job name, pay rate and hours worked
			String jobTitle = getFromUser("job title");
			int hourlyRate = getIntFromUser("hourly rate for " + jobTitle);
			int hours = getIntFromUser("hours worked for " + jobTitle);

			//update invoice
			breakdownOfCosts += addEmployeeToInvoice(jobTitle, hourlyRate, hours);
			totalHours += hours;
			totalOwing += (hourlyRate * hours);

			//add more employees to the invoice?
			String more = getFromUser("another worker? Yes/No");
			if (more.trim().toLowerCase().startsWith("n")) {
				keepGoing = false;
			}
		} //all done with user input.

		//print the formatted invoice
		printInvoice(name, address, totalHours, totalOwing, breakdownOfCosts);

		//clean up
		in.close();
	}

	private static String addEmployeeToInvoice(String jobTitle, int hourlyRate, int hours) {
		//format: name, £hourly rate, hours worked, £amount owed
		return String.format("%-25s\t£%d\t\t%d\t\t£%d%n", jobTitle, hourlyRate, hours, hourlyRate *hours);
	}

	private static String getAddress() {
		System.out.println("Enter address of the company. Type a blank line when you are done. ");
		System.out.print(">: ");

		String address = "";
		String temp = "";
		boolean go = true;
		//loop until the user enters a blank line
		while (go) {
			temp = in.nextLine();
			if (temp.isEmpty()) {
				go = false;
			} else {
				address += String.format("%s%n",temp);
			}
		}

		return address;
	}

	private static String getFromUser(String prompt) {
		System.out.print("Enter " + prompt + ": ");
		return in.nextLine();
	}

	private static int getIntFromUser(String prompt) {
		boolean keepGoing = true;
		int i = 0;
		while (keepGoing) {
			System.out.print("Enter " + prompt + ": ");
			i = in.nextInt();

			in.nextLine(); //read the read of the line that had the int.
			//without this, running getIntFromUser() followed by getFromUser()
			//would result in getFromUser() returning the rest of the line that the int was part of
			//(ie probably just a newline character)

			if (i < 1) { //make sure the number is more than 0
				System.out.println("Invalid number. Number must be greater than zero.");
			} else {
				keepGoing = false;
			}
		}
		return i;
	}

	private static void printInvoice(String name, String address, int totalHours, int totalBeforeVat, String breakdownOfCosts) {
		int vat = getVat(totalBeforeVat);
		int totalWithVat = addVat(totalBeforeVat);

		// \t = tab, %n = newline

		String s = String.format("\t\t\t%s%n%n%n", COMPANY_NAME);

		s += String.format("INVOICE%n%n%s%n%n", getTodaysDate());
		s += String.format("%s%n%s%n%s%n%s%n%n", COMPANY_NAME, COMPANY_ADDRESS1, COMPANY_ADDRESS2, COMPANY_POSTCODE);
		s += String.format("TO%n%s%n%s%n%n", name, address);
		s += String.format("JOB TITLE\t\t\tHOURLY RATE\tHOURS WORKED\tAMOUNT%n%s%n", breakdownOfCosts);
		s += String.format("Total Hours\t\t\t\t\t\t\t%d%n", totalHours);
		s += String.format("Total Before VAT\t\t\t\t\t\t£%d%n", totalBeforeVat);
		s += String.format("VAT @ 20%%\t\t\t\t\t\t\t£%d%n%n", vat);
		s += String.format("==========================================================================%n","");
		s += String.format("TOTAL PAYABLE\t\t\t\t\t\t\t£%d%n", totalWithVat);
		s += String.format("==========================================================================%n%n%n","");
		s += String.format("DETAILS%nSee attached time sheets.%n%n%nPAYMENT%nMake all cheques payable to %s%n", COMPANY_PAYABLE_NAME);
		s += String.format("Total due in 30 days from date of invoice.%n%n%nThe total payment of £%d is due on or before %s.%n%n%n", totalWithVat, getDateIn30Days());
		s += String.format("Thank you for your custom.%n%n%n\t\t%s", COMPANY_SLOGAN);

		System.out.println(s);
	}

	private static String getDateIn30Days() {
		Calendar thirtyDaysInFuture = Calendar.getInstance(); //today's date
		thirtyDaysInFuture.add(Calendar.DAY_OF_YEAR, 30); //+ 30 days

		//format returned is yyyy-mm-dd (dd mon yyyy)
		return String.format("%1$tF (%1$te %1$tb %1$tY)", thirtyDaysInFuture);
	}

	private static String getTodaysDate() {
		Calendar today = Calendar.getInstance();

		//format returned is dd/mm/yy
		return String.format("%1$te/%1$tm/%1$ty", today);
	}

	private static int addVat(int amount) {
		int vat = getVat(amount);

		return amount + vat;
	}
	private static int getVat(int amount) {
		//Potential pitfall: if you divide first you may end up getting 0 when there is vat because integer division discards anything after the decimal point
		return (amount*20)/100; //vat = 20%
	}

	public static void main(String[] args) {
		InvoiceCreator.create();
	}
}
