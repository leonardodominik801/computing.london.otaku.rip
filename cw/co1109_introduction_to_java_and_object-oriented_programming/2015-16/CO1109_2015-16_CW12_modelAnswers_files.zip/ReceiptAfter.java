import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


public class ReceiptAfter {
	private static final String RECEIPT_HEADER = "Your receipt from Wellard's organic supermarket";
	private static final String RECEIPT_FOOTER_LINE1 = "Please note product expiry dates are an indication only.";
	private static final String RECEIPT_FOOTER_LINE2 = "Wellards accepts no liability for stated expiry dates,";
	private static final String RECEIPT_FOOTER_LINE3 = "please refer to individual packaging to confirm use by and best before dates.";

	private List<String> receipt; //the final, formatted receipt
	private List<String> lines; //contents of the ... not-quite-receipt

	public ReceiptAfter(String filename) {
		lines = Receipts.readFromFile(filename);
		receipt = new ArrayList<>();
		construct();
	}

	private void construct() {
		List<String> orderDetails = lines.subList(0, 11);
		List<String> goods = lines.subList(14, lines.size());

		List<String> itemised = getItemisedBill(goods);
		List<String> details = getCustomerDetails(orderDetails);

		BigDecimal subTotal = getPrice(goods);
		List<String> total = getCostBreakdown(orderDetails, subTotal);

		receipt.add("\t\t\t" + RECEIPT_HEADER);
		receipt.add("");
		receipt.add("");
		receipt.addAll(details);
		receipt.add("");
		receipt.add("");
		receipt.addAll(total);
		receipt.add("");
		receipt.add("");
		receipt.addAll(itemised);
		receipt.add("");
		receipt.add("");
		receipt.add("\t" + RECEIPT_FOOTER_LINE1);
		receipt.add("\t" + RECEIPT_FOOTER_LINE2);
		receipt.add("\t" + RECEIPT_FOOTER_LINE3);
	}

	private static BigDecimal getPrice(List<String> goods) {
		BigDecimal bd = new BigDecimal(0);

		for (String line : goods) {
			String[] ary = line.split(",");

			bd = bd.add(new BigDecimal(ary[3]));
		}

		return bd;
	}

	private static List<String> getCustomerDetails(List<String> details) {
		List<String> customer = new ArrayList<>();

		String nameLine = details.get(0);
		String[] tmp = nameLine.split(": ");
		String[] name = tmp[1].split(" "); //["smith,", "sarah", "ms"]

		String surname = name[0];
		surname = surname.substring(0, surname.length()-1); //remove ',' from end of name

		customer.add( String.format("%s %s %s", name[2], name[1], surname) );
		customer.add(details.get(1)); //add the 'order number' line as is
		customer.add(details.get(2)); //same with the 'delivery date' line
		customer.add("Customer Service team: 0345 000 000 (open 8am to 11pm every day) or");
		customer.add("wellards@wellards.com");

		return customer;
	}

	private static List<String> getCostBreakdown(List<String> details, BigDecimal goodsTotal) {
		List<String> costs = new ArrayList<>();

		String[] voucherLine = details.get(3).split(": ");
		String[] deliveryLine = details.get(4).split(": ");
		String[] cardLine = details.get(5).split(": ");
		String[] card = cardLine[1].split(" ");

		BigDecimal pAndP = new BigDecimal(deliveryLine[1]);
		BigDecimal voucher = new BigDecimal(voucherLine[1]);
		BigDecimal total = goodsTotal.add(pAndP).add(voucher);

		costs.add( String.format("%-30s\t\t£%.2f","Cost of goods", goodsTotal) );
		costs.add( String.format("%-30s\t\t£%.2f", "Picking, packing and delivery", pAndP) );
		costs.add( String.format("%-30s\t\t-£%.2f", voucherLine[0], voucher.abs()) );
		costs.add( String.format("%-30s\t\t£%.2f", "Total charge", total) );
		costs.add( String.format("%s%nCard: %s Last four digits: %s", "Payment details", card[0], card[4]) );

		return costs;
	}

	private static List<String> getItemisedBill(List<String> goods) {
		List<String> bill = new ArrayList<>();
		bill.add(String.format("%-32s%s\t%s\t%s","Item","Quantity","Price","Price to pay (£)"));

		for (String line : goods) {
			String[] ary = line.split(",");
			String s = String.format("%-32s%s\t\t%s\t%s", ary[0], ary[1], ary[2], ary[3]);
			bill.add(s);
		}

		return bill;
	}

	public void write(String filename) {
		Receipts.writeToFile(filename, receipt);
	}

	public static void main(String[] args) {
		ReceiptAfter ra = new ReceiptAfter("receipt info.txt");
		ra.write("final receipt.txt");
	}

}
