import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;


public class StringInput {

	private Scanner in;

	public StringInput() {
		in = new Scanner(System.in);
		startLoop();
	}

	private void startLoop() {
			String word = getWordFromUserInput();

			boolean quit = false;
				showOptions(word);
				String userInput = getUserSelectedOption();

				int option = validateUserInput(userInput);
				if (option == 8) { //option to quit
					quit = true;
				} else {
					executeUserSelectedOption(option, word);
				}

		//the end.
		System.out.println("Bye.");
		end();
	}

	private void end() {
		in.close();
	}

	private boolean askUserIfContinue() {
		System.out.print("Do you want to enter another word? Yes/No: ");
		String s = getUserInput();
		if (s.trim().toLowerCase().startsWith("y")) {
			return true;
		} else {
			return false;
		}
	}

	private String getWordFromUserInput() {
		System.out.print("Enter a word: ");
		String s = getUserInput();
		System.out.println();

		return s.trim();
	}

	private String getUserInput() {
		return in.nextLine();
	}

	private void showOptions(String word) {
		System.out.println("Current word: '" + word + "'");
		System.out.println("Choose one of the following options:");
		System.out.println("1)\tRepeat");
		System.out.println("2)\tReverse");
		System.out.println("3)\tArrange Alphabetically");
		System.out.println("4)\tRandomise");
		System.out.println("5)\tFrequency Count");
		System.out.println("6)\tRemove Vowels");
		System.out.println("7)\tInsert Spaces");
		System.out.println("8)\tQuit");
		System.out.println();
	}

	private String getUserSelectedOption() {
		System.out.print("Enter your choice: ");
		String s = getUserInput();
		System.out.println();
		return s;
	}

	private int validateUserInput(String data) {
		if (data == null || data.trim().length() == 0) {
			return -1;
		}

		String possibleNumber = data.trim();
		if (possibleNumber.length() > 1) { //change the 1 to 2 if we go over 9 options (change again to 3 if we go over 99 options...)
			return -1;
		}

		if (possibleNumber.equals("1")) return 1;
		if (possibleNumber.equals("2")) return 2;
		if (possibleNumber.equals("3")) return 3;
		if (possibleNumber.equals("4")) return 4;
		if (possibleNumber.equals("5")) return 5;
		if (possibleNumber.equals("6")) return 6;
		if (possibleNumber.equals("7")) return 7;
		if (possibleNumber.equals("8")) return 8;

		return -1;
	}

	private void executeUserSelectedOption(int option, String word) {
		if (option < 1) {
			System.out.println("Unknown option.");
			return;
		}

		switch (option) {
			case 1: echo(word); break;
			case 2: System.out.println("I don't know how to do that."); break;
			case 3: alphabetise(word); break;
			case 4: System.out.println("I don't know how to do that."); break;
			case 5: frequency(word); break;
			case 6: System.out.println("I don't know how to do that."); break;
			case 7: insertSpaces(word); break;

			default: System.out.print("Error executing option.");
		}
		System.out.println();
	}


	private void echo(String word) {
		System.out.println(word);
	}


	private void alphabetise(String word) {
		char[] array = word.toCharArray();
		Arrays.sort(array);
		System.out.println(array);
	}


	private void frequency(String word) {
		word = word.toUpperCase();
		char[] array = word.toCharArray();
		int count;
		int length = array.length;

		for (int i = 0; i < length; i++) {
			count = 0;

			for (int j = 0; j < length; j++) {
				if (j < i && array[i] == array[j]) { //if we're looking at a character we've already seen (and already reported the frequency for)
					break; //break out of the inner loop so as not to re-report it! (de-duplication step)
				}

				if (array[i] == array[j]) {
					count++;
				}

				if (j == length) {
					System.out.println(array[i]+"\t"+count); //output the count on the last iteration of the inner loop
				}
			}
		}
	}



	private void insertSpaces(String word) {
		int length = word.length() - 1;
		String s = "";
		char c;
		for (int i = 0; i < length; i++) {
			c = word.charAt(i);
			s += c + " ";
		}
		//do not add a space after the last character
		c = word.charAt(length);
		s += c;

		System.out.println(s);
	}

	public static void main(String[] args) {
		new StringInput();
	}
}
