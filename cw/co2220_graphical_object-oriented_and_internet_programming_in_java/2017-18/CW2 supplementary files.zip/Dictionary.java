import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;


public class Dictionary {
    private static Dictionary instance;
    public static Dictionary getInstance() {
        if (instance == null) {
            instance = new Dictionary();
        }
        return instance;
    }
    private List<String> words;

    private Dictionary() {
        try {
            words = Files.readAllLines(Paths.get("words.small"));
        } catch (IOException e) {
            System.err.println("dictionary file not found!");
            words = new ArrayList<>(); //empty dictionary
        }
    }

    public boolean contains(String word) {
        return words.contains(word);
    }
}
