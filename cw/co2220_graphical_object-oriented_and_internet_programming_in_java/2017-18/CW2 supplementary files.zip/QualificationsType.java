public enum QualificationsType {
    ACTUAL, POTENTIAL;
}
