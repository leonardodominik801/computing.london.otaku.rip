public enum Gender {
    FEMALE, MALE, OTHER;
}
