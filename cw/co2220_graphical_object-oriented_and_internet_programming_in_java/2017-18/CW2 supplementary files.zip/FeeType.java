public enum FeeType {
    HOME, OVERSEAS;
}
