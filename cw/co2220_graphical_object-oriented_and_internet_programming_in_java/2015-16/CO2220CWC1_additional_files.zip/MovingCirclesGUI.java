import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class MovingCirclesGUI
{
	JFrame frame;
	public int x,y;
	public int diameter=100;
	JButton animateCircleButton;
	CircleDrawPanel drawPanel;
	Color color = Color.orange;
	Random r= new Random();
	boolean start = false;

	public static void main (String[] args)
	{
		MovingCirclesGUI gui = new MovingCirclesGUI();
		gui.go();
	}

	//this method sets up the JFrame, adds the button and drawpanel to the frame and adds the ActionListener to the button
	public void go(){
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		drawPanel = new CircleDrawPanel();
		frame.getContentPane().add(BorderLayout.CENTER, drawPanel);

		animateCircleButton = new JButton("Click me to start the animation");
		animateCircleButton.addActionListener(new AnimateCircleListener());
		frame.getContentPane().add(BorderLayout.SOUTH, animateCircleButton);

		frame.setSize(500,500);
		frame.setVisible(true);
	}

	//if the button is clicked start or stop the animation
	class AnimateCircleListener implements ActionListener{
		public void actionPerformed (ActionEvent e){
			start = !start;
			if (start) animateCircleButton.setText("Click me to stop the animation");
			if (!start) animateCircleButton.setText("Click me to start the animation");
			drawPanel.repaint();
		}
	}


	class CircleDrawPanel extends JPanel{
		public void paintComponent (Graphics g){
			super.paintComponent(g);
			Graphics2D g2=(Graphics2D)g;
			g2.setColor(color);
			g2.fillOval(x,y,diameter,diameter);
			if (start == true){
				x = r.nextInt(this.getWidth());
				while(x>this.getWidth()- diameter) x=r.nextInt(this.getWidth());
				y = r.nextInt(this.getHeight());
				while(y>this.getHeight()- diameter) y=r.nextInt(this.getHeight());
				repaint();
				try{
					Thread.sleep(500);
				}
				catch(Exception e){}
			}
		}
	}
}
