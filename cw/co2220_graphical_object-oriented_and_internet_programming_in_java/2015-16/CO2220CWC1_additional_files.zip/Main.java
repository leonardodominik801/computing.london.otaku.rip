import java.util.List;


public class Main {


	public static void main(String[] args) {
		//read in books and sort by author name
		List<Book> books = BookCSVParser.parseBookChart("books.csv");
		//System.out.println();
		System.out.println("LIST OF BOOKS BY AUTHOR");
		System.out.println();
		books.sort(new BookAuthorComparator());
		for(Book b : books) {
			System.out.println(b);
		}

		//read in ebooks and sort by author name
		List<EBook> eBooks = EBookCSVParser.parseEBookChart("ebooks.csv");
		System.out.println();
		System.out.println("LIST OF EBOOKS BY AUTHOR");
		System.out.println();
		eBooks.sort(new BookAuthorComparator());
		for(EBook eb : eBooks) {
			System.out.println(eb);
		}


		//read in audio books and sort by author name
		List<AudioBook> audioBooks = AudioBookCSVParser.parseAudioBookChart("audiobooks.csv");
		System.out.println();
		System.out.println("LIST OF AUDIOBOOKS BY AUTHOR");
		System.out.println();
		audioBooks.sort(new BookAuthorComparator());
		for(AudioBook ab : audioBooks) {
			System.out.println(ab);
		}



		//sort books into bestseller chart
		System.out.println();
		System.out.println("LIST OF BESTSELLING BOOKS");
		System.out.println();
		books.sort(new BookSalesComparator());
		for(Book b : books) {
			System.out.println(b);
		}


		//sort ebooks into bestseller chart
		System.out.println();
		System.out.println("LIST OF BESTSELLING EBOOKS");
		System.out.println();
		eBooks.sort(new BookSalesComparator());
		for(EBook eb : eBooks) {
			System.out.println(eb);
		}


		//sort audiobooks into bestseller chart
		System.out.println();
		System.out.println("LIST OF BESTSELLING AUDIOBOOKS");
		System.out.println();
		audioBooks.sort(new BookSalesComparator());
		for(AudioBook ab : audioBooks) {
			System.out.println(ab);
		}

	}
}
