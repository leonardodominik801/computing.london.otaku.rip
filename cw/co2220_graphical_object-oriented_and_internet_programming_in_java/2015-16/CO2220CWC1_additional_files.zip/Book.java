public class Book extends AbstractBook {
	public Book(String title, String author, ISBN isbn, String publisher, String genre,
			int yearOfPublication, BookLength pageCount) {
		super(title, author, isbn, publisher, genre, yearOfPublication, pageCount);
	}
	
	public String getIsbn() {
		return this.id.getId();
	}

	public int getPageCount() {
		return this.length.getDuration();
	}
}
