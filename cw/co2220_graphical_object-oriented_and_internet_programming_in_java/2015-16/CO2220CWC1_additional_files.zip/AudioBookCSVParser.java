import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
//make them write the parseBook() method, for this and the other parser classes

public class AudioBookCSVParser {
	public static List<AudioBook> parseAudioBookChart(String filename) {
		Scanner in = getScanner(filename);
		if(in == null) {
			return null;
		}
		List<AudioBook> books = new ArrayList<AudioBook>();
		while(in.hasNextLine()) {
			String line = in.nextLine();
			AudioBook book = parseBook(line);
			books.add(book);
		}
		in.close();
		return books;
	}

	private static Scanner getScanner(String filename) {
		Scanner in = null;

		try {
			in = new Scanner(new FileInputStream(filename), "UTF-8");
		} catch (IOException e) {
			System.err.println("File "+filename+" does not exist.");
			return null;
		}
		//two non-book lines to skip:
		in.nextLine();
		in.nextLine();

		return in;
	}

	private static AudioBook parseBook(String line) {
		String[] details = line.split(";\\s*");

		String title = details[0].trim();
		String auth = details[1].trim();
		String narr = details[2].trim(); //extra field
		String pub = details[3].trim();
		String genre = details[4].trim();
		String asin = details[5].trim(); //isbn in book
		int year = Integer.parseInt(details[6].trim());
		BookLength length = parseLength(details[7].trim()); //pages in book

		AudioBook ab = new AudioBook(title, auth, narr, new ASIN(asin), pub, genre, year, length);

		int sales = Integer.parseInt(details[8].trim());
		ab.setSales(sales);

		return ab;
	}


	private static BookLength parseLength(String details) {
		String[] split = details.split(" "); //[0] now holds a number, and [1] holds the String "minutes"
		int length = Integer.parseInt(split[0]);
		String mins = split[1].toLowerCase().trim();
		return new BookLength(length, mins);
	}

	public static void main(String[] args) {
		List<AudioBook> books = AudioBookCSVParser.parseAudioBookChart("audiobooks.csv");
		for(AudioBook b : books) {
			System.out.println(b);
		}
	}
}
