import java.util.Comparator;


public class BookSalesComparator implements Comparator<AbstractBook> {

	/**
	 * Compare the sales figures of two books
	 *
	 * We want higher numbers to come first, so as to make a 'bestseller list'
	 */

	public int compare(AbstractBook bs1, AbstractBook bs2) {
		int s1 = bs1.getSales();
		int s2 = bs2.getSales();

		//if the first book has higher sales it should come before the second book
		return s1 > s2 ? -1 : s1 == s2 ? 0 : 1;
		//there are other ways of doing the comparison eg
		/*int s1 = bs1.getSales();
		  int s2 = bs2.getSales();
		  return s2-s1;*/

		  // return bs2.getSales() - bs1.getSales();
	}
}
