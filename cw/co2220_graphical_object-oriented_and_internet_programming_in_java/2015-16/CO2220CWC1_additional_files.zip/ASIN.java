
public class ASIN implements BookID {
	private static final String TYPE = "ASIN";
	private String asin;
	
	public ASIN(String asin) {
		this.asin = asin;
	}

	@Override
	public String getId() {
		return asin;
	}
	
	@Override
	public String getType() {
		return TYPE;
	}
	
	public String toString() {
		return TYPE + ": " + asin;
	}
}
