import java.util.Comparator;

public class BookAuthorComparator implements Comparator<AbstractBook>{

	@Override
	public int compare(AbstractBook o1, AbstractBook o2) {
		String n1 = o1.getAuthor();
		String n2 = o2.getAuthor();

		return n1.compareTo(n2);
	}

}
