import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class EBookCSVParser {
	public static List<EBook> parseEBookChart(String filename) {
		Scanner in = getScanner(filename);
		if(in == null) {
			return null;
		}
		List<EBook> books = new ArrayList<EBook>();
		while(in.hasNextLine()) {
			String line = in.nextLine();
			EBook book = parseBook(line);
			books.add(book);
		}
		in.close();
		return books;
	}

	private static Scanner getScanner(String filename) {
		Scanner in = null;

		try {
			in = new Scanner(new FileInputStream(filename), "UTF-8");
		} catch (IOException e) {
			System.err.println("File "+filename+" does not exist.");
			return null;
		}
		//two non-book lines to skip:
		in.nextLine();
		in.nextLine();

		return in;
	}

	private static EBook parseBook(String line) {
		String[] details = line.split(";\\s*");

		String title = details[0].trim();
		String auth = details[1].trim();
		String pub = details[2].trim();
		String genre = details[3].trim();
		String asin = details[4].trim(); //isbn in book
		int year = Integer.parseInt(details[5].trim());
		int wordCount = Integer.parseInt(details[6].trim()); //pages in book

		EBook eb = new EBook(title, auth, new ASIN(asin), pub, genre, year, new BookLength(wordCount, "words"));

		int sales = Integer.parseInt(details[7].trim());
		eb.setSales(sales);

		return eb;
	}

	public static void main(String[] args) {
		List<EBook> books = EBookCSVParser.parseEBookChart("ebooks.csv");
		for(EBook b : books) {
			System.out.println(b);
		}
	}
}
