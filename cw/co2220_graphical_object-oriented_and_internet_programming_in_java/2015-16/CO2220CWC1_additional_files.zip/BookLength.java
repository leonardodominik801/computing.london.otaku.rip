
public class BookLength {
	private int duration;
	private String units;
	
	public BookLength(int duration, String units) {
		this.duration = duration;
		this.units = units;
	}


	public int getDuration() {
		return duration;
	}


	public String getUnits() {
		return units;
	}
	
	public String toString() {
		return  String.format("%,d %s", duration, units);
	}
}
