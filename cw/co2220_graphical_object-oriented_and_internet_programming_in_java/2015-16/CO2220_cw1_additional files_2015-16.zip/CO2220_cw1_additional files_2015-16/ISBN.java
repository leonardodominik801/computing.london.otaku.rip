
public class ISBN implements BookID {
	private static final String TYPE = "ISBN";
	private String isbn;
	
	public ISBN(String isbn) {
		this.isbn = isbn;
	}

	@Override
	public String getType() {
		return TYPE;
	}

	@Override
	public String getId() {
		return isbn;
	}
	
	public String toString() {
		return TYPE + ": " + isbn;
	}
}
