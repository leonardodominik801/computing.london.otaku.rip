import java.util.Comparator;

public class BookAuthorComparator implements Comparator<Book>{

	@Override
	public int compare(Book o1, Book o2) {
		String n1 = o1.getAuthor();
		String n2 = o2.getAuthor();

		return n1.compareTo(n2);
	}

}
