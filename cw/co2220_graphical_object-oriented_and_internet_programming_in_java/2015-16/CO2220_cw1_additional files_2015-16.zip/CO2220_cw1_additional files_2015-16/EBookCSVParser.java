import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class EBookCSVParser {
	public static List<EBook> parseEBookChart(String filename) {
		Scanner in = getScanner(filename);
		if(in == null) {
			return null;
		}
		List<EBook> books = new ArrayList<EBook>();
		while(in.hasNextLine()) {
			String line = in.nextLine();
			EBook book = parseBook(line);
			books.add(book);
		}
		in.close();
		return books;
	}

	private static Scanner getScanner(String filename) {
		Scanner in = null;

		try {
			in = new Scanner(new FileInputStream(filename), "UTF-8");
		} catch (IOException e) {
			System.err.println("File "+filename+" does not exist.");
			return null;
		}
		//two non-book lines to skip:
		in.nextLine();
		in.nextLine();

		return in;
	}

	private static EBook parseBook(String line) {
		return null;
	}

	public static void main(String[] args) {
		List<EBook> books = EBookCSVParser.parseEBookChart("ebooks.csv");
		for(EBook b : books) {
			System.out.println(b);
		}
	}
}
