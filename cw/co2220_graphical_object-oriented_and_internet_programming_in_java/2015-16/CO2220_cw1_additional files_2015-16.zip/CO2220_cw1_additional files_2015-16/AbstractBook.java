
public abstract class AbstractBook {
	protected String title;
	protected String author;
	protected String publisher;
	protected String genre;
	protected int yearOfPublication;
	protected BookLength length;
	protected int sales;
	protected BookID id;
	
	public AbstractBook(String title, String author, BookID id, String publisher, String genre,
			int yearOfPublication, BookLength length) {
		this.title = title;
		this.author = author;
		this.publisher = publisher;
		this.genre = genre;
		this.yearOfPublication = yearOfPublication;
		this.length = length;
		this.id = id;
	}
	
	public int getSales() {
		return sales;
	}

	public void setSales(int sales) {
		this.sales = sales;
	}

	public String getTitle() {
		return title;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public String getPublisher() {
		return publisher;
	}
	
	public String getGenre() {
		return genre;
	}
	
	public int getYearOfPublication() {
		return yearOfPublication;
	}
	
	public String getLength() {
		return length.toString();
	}
	
	public String getId() {
		return id.getId();
	}
	
	public String toString() {
		String s = String.format("Author: %s%n", author);
		s += String.format("Title: %s%n", title);
		s += String.format("Length: %s%n", length);
		s += String.format("Genre: %s%n", genre);
		s += String.format("Year of publication: %d%n", yearOfPublication);
		s += String.format("Publisher: %s%n", publisher);
		s += String.format("%s%n", id);
		s += String.format("Sales: %,d%n", sales);
		
		return s;
	}
}
