
public class EBook extends AbstractBook {
	public EBook(String title, String author, ASIN asin, String publisher, String genre,
			int yearOfPublication, BookLength length) {
		super(title, author, asin, publisher, genre, yearOfPublication, length);
	}
	
	public String getAsin() {
		return this.id.getId();
	}

	public int getWordCount() {
		return this.length.getDuration();
	}
}
