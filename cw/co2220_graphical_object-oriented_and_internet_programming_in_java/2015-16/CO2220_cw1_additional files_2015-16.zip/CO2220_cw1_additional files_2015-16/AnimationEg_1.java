import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/*
  This program will display an oval whose colour keeps changing randomly.
*/

public class AnimationEg_1{
	JFrame frame;
	RandomColDrawPanel drawPanel= new RandomColDrawPanel();


	public static void main (String[] args){
		AnimationEg_1 gui = new AnimationEg_1();
		gui.go();
	}

	public void go(){
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JFrame.setDefaultLookAndFeelDecorated(true);
		frame.getContentPane().add(drawPanel);   //(BorderLayout.CENTER, drawPanel);
		frame.setSize(500,500);
		frame.setVisible(true);
	}


	class RandomColDrawPanel extends JPanel{
		public void paintComponent (Graphics g){
			Graphics2D g2=(Graphics2D)g;
			int r = (int)(Math.random()*255);
			int gr = (int)(Math.random()*255);
			int b = (int)(Math.random()*255);
			g2.setColor(new Color(r,gr,b));
			g2.fillOval(100,25,275,400);
			repaint();
		}
	}
}
