
public class AudioBook extends AbstractBook {
	private String narrator;

	public AudioBook(String title, String author, String narrator, ASIN asin,
			String publisher, String genre, int yearOfPublication, BookLength length) {
		super(title, author, asin, publisher, genre, yearOfPublication, length);

		this.narrator = narrator;
	}

	public String getAsin() {
		return this.id.getId();
	}

	public int getLengthInMinutes() {
		return this.length.getDuration();
	}

	public String getNarrator() {
		return narrator;
	}
}
