import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class MovingCircleGUI{
	JFrame frame;
	public int x,y;
	public int diameter=100;
	CircleDrawPanel drawPanel;
	Color color = Color.orange;

	public static void main (String[] args){
		MovingCircleGUI gui = new MovingCircleGUI();
		gui.go();
	}

	//this method sets up the JFrame and adds the drawpanel to the frame
	public void go(){
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		drawPanel = new CircleDrawPanel();
		frame.getContentPane().add(BorderLayout.CENTER, drawPanel);
		frame.setSize(500,500);
		frame.setVisible(true);
	}


	class CircleDrawPanel extends JPanel{
		public void paintComponent (Graphics g){
			super.paintComponent(g);
			Graphics2D g2=(Graphics2D)g;
			g2.setColor(color);
			g2.fillOval(x,y,diameter,diameter);
		}
	}
}
