import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AudioBookCSVParser {
	public static List<AudioBook> parseAudioBookChart(String filename) {
		Scanner in = getScanner(filename);
		if(in == null) {
			return null;
		}
		List<AudioBook> books = new ArrayList<AudioBook>();
		while(in.hasNextLine()) {
			String line = in.nextLine();
			AudioBook book = parseBook(line);
			books.add(book);
		}
		in.close();
		return books;
	}

	private static Scanner getScanner(String filename) {
		Scanner in = null;

		try {
			in = new Scanner(new FileInputStream(filename), "UTF-8");
		} catch (IOException e) {
			System.err.println("File "+filename+" does not exist.");
			return null;
		}
		//two non-book lines to skip:
		in.nextLine();
		in.nextLine();

		return in;
	}

	private static AudioBook parseBook(String line) {
			return null;
	}


	private static BookLength parseLength(String details) {
		String[] split = details.split(" "); //[0] now holds a number, and [1] holds the String "minutes"
		int length = Integer.parseInt(split[0]);
		String mins = split[1].toLowerCase().trim();
		return new BookLength(length, mins);
	}

	public static void main(String[] args) {
		List<AudioBook> books = AudioBookCSVParser.parseAudioBookChart("audiobooks.csv");
		for(AudioBook b : books) {
			System.out.println(b);
		}
	}
}
