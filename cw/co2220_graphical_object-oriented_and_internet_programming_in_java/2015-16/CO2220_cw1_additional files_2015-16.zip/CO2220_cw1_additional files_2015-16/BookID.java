
public interface BookID {
	public String getType(); //the name of the type of identifier, e.g. ISBN
	public String getId(); //the unique identity code, such as an actual ISBN
}
