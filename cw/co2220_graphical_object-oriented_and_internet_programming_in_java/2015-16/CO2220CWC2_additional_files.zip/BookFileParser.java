import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

public class BookFileParser {
	
	private static String serialFilename = "books.ser";
	
	public static List<Book> fromSerialized(String filename) throws FileNotFoundException, IOException, ClassNotFoundException {
		List<Book> books = null;
		ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename));
		books = (List<Book>) in.readObject(); 
		in.close();
		
		return books;
	}
	
	public static void serializeToDisk(List<Book> books) throws IOException {
		FileOutputStream fos = new FileOutputStream(serialFilename);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(books);
		fos.close();
		oos.close();
	}
}
