
public class Fruit extends Grocery {
	private double pricePerKilo;

	public Fruit(String name, String producer, double price) {
		super(name, producer);
		pricePerKilo = price;
	}

	public Fruit(String name, String producer) {
		this(name, producer, -1);
	}

	public double getPricePerKilo() {
		return pricePerKilo;
	}

	public String toString() {
		String s = super.toString();
		return String.format("%s%-10s %.2f %s%n", s, "Price:", pricePerKilo, "(per kilo)");
	}
}
