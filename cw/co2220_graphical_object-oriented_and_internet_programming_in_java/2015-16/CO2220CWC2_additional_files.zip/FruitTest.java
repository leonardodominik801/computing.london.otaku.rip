import java.util.List;


public class FruitTest {

	public static void main(String[] args) {
		Fruit f = new Fruit("Apple", "Down Dale Farms", 15.5);
		System.out.println(f);

		Grocery g = new Grocery("Leek", "Up Dale Farms");
		System.out.println(g);

		List<Fruit> list = FruitUtils.parseFruitsFromCSV("fruits.csv");

		FruitUtils.displayFruits(list);

		System.out.println("Serializing to disk...");
		FruitUtils.serializeToDisk(list);
		System.out.println("Done.");

		System.out.println("Deserializing...");
		List<Fruit> list2 = FruitUtils.fromSerialized("fruits.ser");
		System.out.println("Printing deserialised list...");
		FruitUtils.displayFruits(list2);

		FruitUtils.writeFruitsToFile(list2);
	}

}
