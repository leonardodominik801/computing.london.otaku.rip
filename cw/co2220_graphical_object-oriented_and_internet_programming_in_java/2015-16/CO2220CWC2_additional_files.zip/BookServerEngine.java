import java.util.ArrayList;
import java.util.List;

public class BookServerEngine {
	private List<Book> books;
	
	public BookServerEngine(List<Book> books) {
		this.books = books;
	}

	public String getAvailableCommands() {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%s%n", "SHOW ALL		show all books"));
		sb.append(String.format("%s%n", "SEARCH <term>	show books that have <term> in the title"));
		sb.append(String.format("%s%n", "SHOW HELP		show this help"));
		return sb.toString();
	}
	
	public String parseCommand(String command) {
		//each command has an instruction and an argument. split the incoming string on the first whitespace character (or whitespace characterS if they are contiguous)
		String[] words = command.split("\\s+", 2);
		if (words.length < 2) {
			return "Syntax: <command> <argument>.";
		}
		
		//make both strings lower case and trim any excess whitespace to make comparisons easier
		String instruction = words[0].toLowerCase().trim();
		String argument = words[1].toLowerCase().trim();
		
		switch (instruction) {
			case "show":
				return show(argument);
			case "search":
				return search(argument);
			default: //everything that isn't a known command
				return "I don't understand '" + instruction + "'.";
		}
	}
	
	private String search(String searchTerm) {
		String term = searchTerm.toLowerCase();
		List<Book> result = new ArrayList<Book>();
		for (Book b : books) {
			if (b.getTitle().toLowerCase().contains(term)) {
				result.add(b);
			}
		}
		
		if (result.size() != 0) {
			return buildResult(result);
		} else {
			return String.format("%s%n", "no results found");
		}
	}

	private String show(String command) {
		switch (command.toLowerCase()) {
			case "help":		return getAvailableCommands();
			case "all":			return getAll();
		
			default: 			return "I don't know how to show that!";
		}
	}
	
	private String getAll() {
		return buildResult(books);
	}
	
	private String buildResult(List<Book> _books) {
		StringBuilder sb = new StringBuilder();
		for (Book b : _books) {
			sb.append(String.format("%s%n", b));
		}
		
		return sb.toString();
	}
	
	public static void main(String[] args) {
		new BookServer();
	}


}
