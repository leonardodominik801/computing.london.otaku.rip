import java.awt.print.Book;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class FruitUtils {

	private FruitUtils() { }

	public static void displayFruits(List<Fruit> list) {
		for (Fruit f : list) {
			System.out.println(f);
		}
	}

	public static List<Fruit> fromSerialized(String filename) {
		List<Fruit> fruits = null;
		ObjectInputStream in;
		try {
			in = new ObjectInputStream(new FileInputStream(filename));
			fruits = (List<Fruit>) in.readObject();
			in.close();
		} catch (ClassNotFoundException e) {
			System.err.println(e);
		} catch (FileNotFoundException e) {
			System.err.format("File not found! %s", e);
			return null;
		} catch (IOException e) {
			System.err.format("Error reading from file: %s", e);
			return null;
		}

		return fruits;
	}

	public static void serializeToDisk(List<Fruit> fruits) {
		FileOutputStream fos;
		ObjectOutputStream oos;
		try {
			fos = new FileOutputStream("fruits.ser");
			oos = new ObjectOutputStream(fos);
			oos.writeObject(fruits);
			fos.close();
			oos.close();
		} catch (FileNotFoundException e) {
			System.err.format("File not found! %s", e);
		} catch (IOException e) {
			System.err.format("Error reading from file: %s", e);
		}
	}

	public static List<Fruit> parseFruitsFromCSV(String filename) {
		Scanner in = null;
		List<Fruit> fruits = new ArrayList<Fruit>();
		try {
			in = new Scanner(new FileReader(filename));
		} catch (IOException e) {
			System.err.println("File "+filename+"does not exist.");
		}
		//first line of the text file is just headings so we do nothing with it. We need things we can turn into Fruit objects!
		in.nextLine();
		while(in.hasNextLine()) {
			String line = in.nextLine();
			Fruit f = parseFruit(line);
			fruits.add(f);
		}
		in.close();
		return fruits;
	}

	private static Fruit parseFruit(String line) {
		String[] details = line.split(", ");

		String name = details[0];
		String producer = details[1];

		if (details.length == 3) {
			double price = Double.valueOf(details[2]);
			return new Fruit(name, producer, price);
		} else {
			return new Fruit(name, producer);
		}
	}

	public static void writeFruitsToFile(List<Fruit> list) {
		try {
			PrintWriter writer = new PrintWriter("fruits-formatted.txt", "UTF-8");

			for (Fruit f : list) {
				writer.println(f);
			}
			writer.flush();
			writer.close();
		} catch (FileNotFoundException e) {
			System.err.format("Couldn't open file for writing. %s", e);
		} catch (UnsupportedEncodingException e) {
			System.err.format("Unknown text encoding. %s", e);
		}
	}

}
