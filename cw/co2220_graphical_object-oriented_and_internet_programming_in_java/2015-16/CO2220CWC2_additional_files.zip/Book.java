import java.io.Serializable;

public class Book implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String title;
	private String author;
	private String genre;
	private String isbn;
	private int publicationYear;
	private int sales;
	private int pages;
	
	public Book(String title, String author, String genre, String isbn, int pages, int publicationYear, int sales) {
		this.title = title;
		this.author = author;
		this.genre = genre;
		this.isbn = isbn;
		this.pages = pages;
		this.publicationYear = publicationYear;
		this.sales = sales;
	}
	
	public String getTitle() {
		return title;
	}
	public String getAuthor() {
		return author;
	}
	public String getIsbn() {
		return isbn;
	}
	public int getPublicationYear() {
		return publicationYear;
	}
	public int getSales() {
		return sales;
	}
	
	public int getPages() {
		return pages;
	}
	
	public String getGenre() {
		return genre;
	}
	
	public String toString() {
		return String.format("%s by %s. %d pages. Genre: %s. Published %d. ISBN: %s. Sales: %d.", title, author, pages, genre, publicationYear, isbn, sales);
	}

}
