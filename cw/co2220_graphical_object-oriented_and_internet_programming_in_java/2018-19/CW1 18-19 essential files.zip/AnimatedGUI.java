import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics.*;

public class AnimatedGUI implements ActionListener
{
	private JFrame frame;
	private int x;
	private int diameter;
	private boolean animateShapes;
	private JButton startStopAnimationButton;
	private ShapesDrawPanel drawPanel;
	
	public AnimatedGUI(){
		x = 1;
		diameter=50;
		animateShapes = true;
		startStopAnimationButton = new JButton("click me to stop the animation");
		drawPanel = new ShapesDrawPanel();
	}		

	public static void main (String[] args){
		AnimatedGUI gui = new AnimatedGUI();
		gui.go();
	}

	public void go(){
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.getContentPane().add(startStopAnimationButton, BorderLayout.PAGE_START);
		frame.getContentPane().add(drawPanel, BorderLayout.CENTER);
		startStopAnimationButton.addActionListener(this);

		frame.setSize(500,500);
		frame.setVisible(true);
	}

	public void actionPerformed (ActionEvent e){
		animateShapes=false;
		drawPanel.repaint();
	}



	class ShapesDrawPanel extends JPanel{
		public void paintComponent (Graphics g){
			Graphics2D g2=(Graphics2D)g;
			g2.setColor(Color.yellow);
			g2.fillRect(0,0,this.getWidth(), this.getHeight());
			g2.setColor(Color.blue);
			g2.fillOval((this.getWidth()-(diameter+x))/2,(this.getHeight()-(diameter+x))/2,diameter+x,diameter+x);
			g2.setColor(Color.red);
			g2.fillRect(x,0,50,50);
			if (animateShapes) animateShapes();
		}
		
		public void animateShapes(){
			try{
				Thread.sleep(5);
			}
			catch (Exception ex){}
			x++; 
			repaint();
		}	
	}
}