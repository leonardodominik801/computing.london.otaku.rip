import java.io.*;
import java.nio.charset.StandardCharsets;

public class LeagueTableFileWriter {
    public static void write(String league, File file) throws IOException {
    }
}
