import java.io.*;
import java.util.ArrayList;

public class SerializationUtil {
	
	private SerializationUtil(){}
	
    public static void serialize(ArrayList<DatedMatchResult> results, File file) throws FileNotFoundException, IOException {
        FileOutputStream fos = new FileOutputStream(file);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(results);
        fos.close();
        oos.close();
    }

    public static ArrayList<DatedMatchResult> deserialize(File file) throws FileNotFoundException, IOException, ClassNotFoundException {
        ArrayList<DatedMatchResult> clubs = null;
        ObjectInputStream in = new ObjectInputStream(new FileInputStream(file));
        clubs = (ArrayList<DatedMatchResult>) in.readObject(); //casting to a parameterized type (in this case ArrayList<DatedMatchResult>. DatedMatchResult is the parameterized type) will always result in an unchecked warning.
        in.close();

        return clubs;
    }
}
