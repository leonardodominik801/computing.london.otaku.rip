import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class MatchResultsClient {
	
	private int port = 6006;

	public void go(String host) {
		
		try {
			System.out.println("Contacting " + host + " on port " + port);
			
			Socket socket = new Socket("localhost", port);
			ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
			ArrayList<DatedMatchResultV2> results = (ArrayList<DatedMatchResultV2>)ois.readObject();
			ois.close();
			socket.close();
			for (DatedMatchResultV2 mr : results) System.out.println(mr); 
		} 
		catch (UnknownHostException e) {
			e.printStackTrace();
		} 
		catch (StreamCorruptedException e) {
			e.printStackTrace();
		}
		catch (InvalidClassException e) {
			e.printStackTrace();
		}
		catch (OptionalDataException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		} 
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}		
	}

	public static void main(final String[] args) {
		new MatchResultsClient().go("results host");
	}
}

