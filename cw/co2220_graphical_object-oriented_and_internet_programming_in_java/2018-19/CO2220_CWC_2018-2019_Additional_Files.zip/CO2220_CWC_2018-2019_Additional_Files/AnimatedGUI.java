import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics.*;

public class AnimatedGUI{
	
	private JFrame frame;
	private int circleX;
	private int squareX;
	private int diameter;
	private boolean animateCircle;
	private boolean animateSquare;
	private boolean moveSquare;
	private boolean growCircle;
	private JButton growCircleButton;
	private JButton moveSquareButton;
	private ShapesDrawPanel drawPanel;
		
	public AnimatedGUI(){
		circleX = 1;
		squareX = 1;
		diameter=50;
		animateCircle = true;
		animateSquare = true;
		moveSquare = true;
		growCircle = true;
		growCircleButton = new JButton("click me to stop or start the circle growing");
		moveSquareButton = new JButton("click me to stop or start the square moving");
		drawPanel = new ShapesDrawPanel();
	}
		

	public static void main (String[] args){
		AnimatedGUI gui = new AnimatedGUI();
		gui.go();
	}

	public void go(){
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		growCircleButton.addActionListener(new growCircleListener());
		moveSquareButton.addActionListener(new shrinkListener());
		
		frame.getContentPane().add(moveSquareButton, BorderLayout.PAGE_START);
		frame.getContentPane().add(drawPanel, BorderLayout.CENTER);
		frame.getContentPane().add(growCircleButton, BorderLayout.PAGE_END);

		frame.setSize(500,500);
		frame.setVisible(true);
	}


	class growCircleListener implements ActionListener{
		public void actionPerformed (ActionEvent e){
			animateCircle=!animateCircle;
			drawPanel.repaint();
		}
	}


	class shrinkListener implements ActionListener{
		public void actionPerformed (ActionEvent e){
			animateSquare=!animateSquare;
			drawPanel.repaint();
		}
	}

	class ShapesDrawPanel extends JPanel{
		public void paintComponent (Graphics g){
			Graphics2D g2=(Graphics2D)g;
			g2.setColor(Color.yellow);
		    g2.fillRect(0,0,this.getWidth(), this.getHeight());
			g2.setColor(Color.blue);
			g2.fillOval((this.getWidth()-(diameter+circleX))/2,(this.getHeight()-(diameter+circleX))/2,diameter+circleX,diameter+circleX);
			g2.setColor(Color.red);
			g2.fillRect(squareX,0,50,50);
			if ((circleX==0)||circleX==600) growCircle=!growCircle;
			if ((squareX==0)||squareX==this.getWidth()-50) moveSquare=!moveSquare;
			if (animateCircle) growCircle();
			if (animateSquare) moveSquare();
		}
		
		public void growCircle(){
			try{
				Thread.sleep(5);
			}
			catch (Exception ex){}
			if (growCircle)circleX++; else circleX--;
			repaint();
		}
		
		public void moveSquare(){
			try{
				Thread.sleep(5);
			}
			catch (Exception ex){}
			if (moveSquare)squareX++; else squareX--;
			repaint();
		}
		
	}
}