import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class WordSleuth extends AbstractRandomWordGame {
    private String wordToGuess;
    private int numberOfGoesLeft;
    private List<Integer> hintCharacterPositions;
    private int score;
    private boolean gameRunning;

    public static void main(String[] args) {
        WordSleuth wordSleuth = new WordSleuth(System.in, System.out);
        wordSleuth.play();
    }

    public WordSleuth(InputStream input, PrintStream output) {
        this(input, output, null, null);
    }

    public WordSleuth(InputStream input, PrintStream output, Path wordsFilePath) {
        this(input, output, wordsFilePath, null);
    }

    public WordSleuth(InputStream input, PrintStream output, Path wordsFilePath, Charset wordsFileCharset) {
        super(input, output, wordsFilePath, wordsFileCharset);
    }

    public void play() {
        initialiseGameState();
        showOpeningInformation();
        while (gameRunning) {
            askUserToGuess();
            String guess = getUserGuess();
            evaluateGuess(guess);
            decideNextStep();
        }
    }

    private void initialiseGameState() {
        wordToGuess = getRandomWord();
        hintCharacterPositions = new ArrayList<Integer>();
        hintCharacterPositions.add(0); //add the first letter since it's the first clue
        numberOfGoesLeft = getNumberOfGuesses(wordToGuess);
        gameRunning = true;
        score = getMaximumScore();
    }

    private void showOpeningInformation() {
        output.println("Word starts with '" + wordToGuess.charAt(0) + "' and is " + wordToGuess.length() + " letters long. You have " + numberOfGoesLeft + " guesses.");
    }

    private void askUserToGuess() {
        output.print("Enter your guess: ");
    }

    private String getUserGuess() {
        return input.nextLine();
    }

    private void evaluateGuess(String guess) {
        if (hasUserWon(guess)) {
            userWins();
        } else {
            incorrectGuess();
        }
    }

    private void decideNextStep() {
        //do nothing if the game is over
        if (!gameRunning) {
            return;
        }

        if (userHasMoreThanOneGuessLeft()) {
            showHint();
        } else if (userOnFinalGuess()) {
            finalHint();
        } else {
            userLoses();
        }
    }

    private int getNumberOfGuesses(String word) {
        float goes = word.length() / 2.0f;
        goes++;
        return Math.round(goes);
    }

    private int getMaximumScore() {
        return wordToGuess.length() * 2;
    }

    private boolean hasUserWon(String guess) {
        return guess.trim().equalsIgnoreCase(wordToGuess);
    }

    private void userWins() {
        gameOver();
        showUserWins();
    }

    private void incorrectGuess() {
        numberOfGoesLeft--;
        score--;
        output.println("Not the right answer. " + numberOfGoesLeft + " guesses left.");
    }

    private boolean userHasMoreThanOneGuessLeft() {
        return numberOfGoesLeft > 1;
    }

    private void showHint() {
        int c = getHint();
        hintCharacterPositions.add(c);
        output.println("Word contains the letter '" + wordToGuess.charAt(c) + "'");
    }

    private boolean userOnFinalGuess() {
        return numberOfGoesLeft == 1;
    }

    private void finalHint() {
        score--;
        showFinalHint();
    }

    private void userLoses() {
        gameOver();
        showUserLoses();
    }

    private void gameOver() {
        gameRunning = false;
    }

    private void showUserWins() {
        output.println("Congratulations! You got it right.");
        showWinningMessages();
    }

    private int getHint() {
        while (true) {
            int candidate = random.nextInt(wordToGuess.length());
            if (acceptableHint(candidate)) {
                return candidate;
            }
        }
    }

    private void showUserLoses() {
        output.println("You lose. The word was " + wordToGuess);
    }

    private void showFinalHint() {
        String finalHint = getFinalHint();
        output.println("FINAL CHANCE: the letters appear in the word in this order: " + finalHint);
    }

    private void showWinningMessages() {
        showScore();
        showScoreEvaluation();
    }

    private void showScore() {
        output.println("you scored " + score);
    }

    private void showScoreEvaluation() {
        String evaluation = getScoreEvaluation();
        output.println(evaluation);
    }

    /*
     * return all the hints in the order that they appear in the word
     */
    private String getFinalHint() {
        String clue = "";
        Collections.sort(hintCharacterPositions);
        for (int position : hintCharacterPositions) {
            clue += wordToGuess.charAt(position);
        }

        return clue;
    }

    private boolean acceptableHint(int characterPosition) {
        return !hintCharacterPositions.contains(characterPosition);
    }

    private String getScoreEvaluation() {
        if (score == getMaximumScore())
            return "A perfect score!";
        else
            return "Well done!";
    }
}
