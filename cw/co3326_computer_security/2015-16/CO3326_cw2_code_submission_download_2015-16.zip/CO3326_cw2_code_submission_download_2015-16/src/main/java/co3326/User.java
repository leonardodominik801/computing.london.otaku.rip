package co3326;

public class User {
        
    public int[] send(User user, String message)  {
        // TODO implement
        return null;
    }
    
    public String receive(User user, int[] cipher) {
        // TODO implement
        return null;
    }
       
}
