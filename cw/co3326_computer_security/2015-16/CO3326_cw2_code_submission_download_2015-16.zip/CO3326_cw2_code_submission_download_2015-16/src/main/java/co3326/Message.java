package co3326;

public class Message {

    protected String text;
    protected int[] encoded;
    protected int[] encrypted;

}
