package co3326;

import java.util.List;

public class Cw1 {

    protected User alice;
    protected User bob;
    protected User charlie;
    protected List<Message> communication;

    public Cw1() {}

    public void demonstrate() {
        /*
         * TODO Pull the first / only message from the list, encode the text and demonstrate the
         * communication trail as Alice sends a message to Bob and is intercepted by Charlie by
         * appending the <i>communication</i> list with all messages involved in the communication
         */
    }

}
